SELECT
  EXP("t0"."double_col") AS "Exp(double_col)"
FROM "functional_alltypes" AS "t0"