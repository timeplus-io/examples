SELECT
  intDivOrZero("t0"."double_col", ABS("t0"."double_col")) AS "Sign(double_col)"
FROM "functional_alltypes" AS "t0"