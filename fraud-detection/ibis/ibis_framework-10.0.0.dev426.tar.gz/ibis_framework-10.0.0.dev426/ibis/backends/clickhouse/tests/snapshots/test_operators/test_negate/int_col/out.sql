SELECT
  -(
    "t0"."int_col"
  ) AS "Negate(int_col)"
FROM "functional_alltypes" AS "t0"