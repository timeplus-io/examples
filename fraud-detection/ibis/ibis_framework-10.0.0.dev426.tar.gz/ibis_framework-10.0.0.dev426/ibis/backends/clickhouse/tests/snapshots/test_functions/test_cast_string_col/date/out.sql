SELECT
  CAST("t0"."string_col" AS Nullable(DATE)) AS "Cast(string_col, date)"
FROM "functional_alltypes" AS "t0"