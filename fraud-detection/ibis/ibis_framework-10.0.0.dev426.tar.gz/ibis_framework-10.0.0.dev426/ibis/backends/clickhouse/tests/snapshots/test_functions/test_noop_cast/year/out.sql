SELECT
  "t0"."year" AS "year"
FROM "functional_alltypes" AS "t0"