SELECT
  CAST('1.0' AS REAL) AS "Cast('1.0', float32)"