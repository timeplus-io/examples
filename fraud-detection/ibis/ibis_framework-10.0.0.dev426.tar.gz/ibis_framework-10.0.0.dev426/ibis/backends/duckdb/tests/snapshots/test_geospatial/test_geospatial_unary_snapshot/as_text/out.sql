SELECT
  ST_ASTEXT("t0"."geom") AS "tmp"
FROM "t" AS "t0"