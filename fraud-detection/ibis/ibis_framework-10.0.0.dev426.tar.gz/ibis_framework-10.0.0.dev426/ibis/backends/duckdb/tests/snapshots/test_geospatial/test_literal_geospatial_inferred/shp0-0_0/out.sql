SELECT
  *
  REPLACE (ST_ASWKB("result") AS "result")
FROM (
  SELECT
    ST_GEOMFROMTEXT('POINT (0 0)') AS "result"
)