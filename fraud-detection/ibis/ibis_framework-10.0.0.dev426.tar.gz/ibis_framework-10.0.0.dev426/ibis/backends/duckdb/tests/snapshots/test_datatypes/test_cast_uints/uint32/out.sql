SELECT
  CAST("t0"."a" AS UINTEGER) AS "Cast(a, uint32)"
FROM "t" AS "t0"