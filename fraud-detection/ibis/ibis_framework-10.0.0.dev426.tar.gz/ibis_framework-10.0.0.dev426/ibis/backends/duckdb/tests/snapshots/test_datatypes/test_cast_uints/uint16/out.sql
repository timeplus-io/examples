SELECT
  CAST("t0"."a" AS USMALLINT) AS "Cast(a, uint16)"
FROM "t" AS "t0"