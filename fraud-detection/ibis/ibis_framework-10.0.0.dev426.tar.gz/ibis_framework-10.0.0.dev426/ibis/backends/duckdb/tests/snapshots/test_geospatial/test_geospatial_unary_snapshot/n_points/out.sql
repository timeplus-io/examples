SELECT
  ST_NPOINTS("t0"."geom") AS "tmp"
FROM "t" AS "t0"