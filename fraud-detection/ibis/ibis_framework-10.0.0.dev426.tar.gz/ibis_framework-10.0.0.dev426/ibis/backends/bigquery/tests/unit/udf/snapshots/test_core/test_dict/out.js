function f() {
    let a = {['a']: 1, ['b']: 2};
    return a;
}