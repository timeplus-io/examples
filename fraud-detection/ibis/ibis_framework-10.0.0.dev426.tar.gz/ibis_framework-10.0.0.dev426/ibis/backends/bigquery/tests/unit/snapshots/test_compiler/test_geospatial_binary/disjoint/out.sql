SELECT
  st_disjoint(`t0`.`geog0`, `t0`.`geog1`) AS `tmp`
FROM `t` AS `t0`