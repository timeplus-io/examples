SELECT
  farm_fingerprint(CAST('74657374206f662068617368' AS BYTES FORMAT 'HEX')) AS `Hash_b'test of hash'`