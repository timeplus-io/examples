SELECT
  st_x(`t0`.`pt`) AS `tmp`
FROM `t` AS `t0`