SELECT
  st_boundingbox(`t0`.`geog`).ymin AS `tmp`
FROM `t` AS `t0`