SELECT
  TIME(`t0`.`ts`) AS `tmp`
FROM `t` AS `t0`