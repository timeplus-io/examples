SELECT
  sha512('test') AS `tmp`