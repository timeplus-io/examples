SELECT
  st_y(`t0`.`pt`) AS `tmp`
FROM `t` AS `t0`