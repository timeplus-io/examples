function f() {
    let a = ['a', 'b', 'c'];
    return a;
}