function f(a) {
    let x = (new Set());
    let y = 1;
    x.add(y);
    return y;
}