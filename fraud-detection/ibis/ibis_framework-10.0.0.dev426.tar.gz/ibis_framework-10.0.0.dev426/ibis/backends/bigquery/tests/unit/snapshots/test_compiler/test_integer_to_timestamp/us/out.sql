SELECT
  timestamp_micros(123456789) AS `tmp`