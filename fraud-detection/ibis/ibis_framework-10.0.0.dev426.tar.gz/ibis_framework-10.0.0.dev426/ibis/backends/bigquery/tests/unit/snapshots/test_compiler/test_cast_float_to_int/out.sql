SELECT
  CAST(trunc(`t0`.`double_col`) AS INT64) AS `Cast_double_col_int64`
FROM `functional_alltypes` AS `t0`