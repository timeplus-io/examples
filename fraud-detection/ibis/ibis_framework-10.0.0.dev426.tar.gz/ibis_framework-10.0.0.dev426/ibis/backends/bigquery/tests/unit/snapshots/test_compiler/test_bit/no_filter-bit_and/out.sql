SELECT
  bit_and(`t0`.`int_col`) AS `BitAnd_int_col`
FROM `functional_alltypes` AS `t0`