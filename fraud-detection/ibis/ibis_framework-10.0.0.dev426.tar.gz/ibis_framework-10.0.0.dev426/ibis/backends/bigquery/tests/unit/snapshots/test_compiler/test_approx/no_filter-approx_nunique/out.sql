SELECT
  APPROX_COUNT_DISTINCT(`t0`.`double_col`) AS `ApproxCountDistinct_double_col`
FROM `functional_alltypes` AS `t0`