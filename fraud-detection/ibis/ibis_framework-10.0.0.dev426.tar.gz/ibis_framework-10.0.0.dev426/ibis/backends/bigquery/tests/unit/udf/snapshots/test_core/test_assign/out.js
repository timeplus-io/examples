function f() {
    let a = 1;
    a = 2;
    console.log(a);
    return 1;
}