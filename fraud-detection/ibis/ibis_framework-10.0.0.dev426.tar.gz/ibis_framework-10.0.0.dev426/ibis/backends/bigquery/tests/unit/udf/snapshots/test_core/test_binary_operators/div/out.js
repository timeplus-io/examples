function div(x, y) {
    return (x / y);
}