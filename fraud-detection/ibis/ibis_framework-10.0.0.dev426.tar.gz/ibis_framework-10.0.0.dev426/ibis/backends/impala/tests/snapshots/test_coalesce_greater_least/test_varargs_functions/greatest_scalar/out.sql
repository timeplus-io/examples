SELECT
  GREATEST(`t0`.`string_col`, 'foo') AS `Greatest((string_col, 'foo'))`
FROM `functional_alltypes` AS `t0`