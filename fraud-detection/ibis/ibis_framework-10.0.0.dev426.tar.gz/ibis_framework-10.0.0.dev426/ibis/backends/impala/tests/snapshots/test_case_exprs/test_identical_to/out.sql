SELECT
  `t0`.`tinyint_col` IS NOT DISTINCT FROM `t0`.`double_col` AS `tmp`
FROM `functional_alltypes` AS `t0`